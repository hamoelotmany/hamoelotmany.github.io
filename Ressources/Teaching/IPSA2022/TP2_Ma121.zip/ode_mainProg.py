#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:43:39 2022
@author: Hammou El-Otmany
@ file used for testing
"""
import sys
from math import *
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pylab import *

#Import functions defined on utils.py and testCase.py
from ode_utils import *
from testCase import *

#Section 1 - Question 3
#ODE: y'=y; y(0) = 0;[a;b]=[0;2]
# fi is given by f(x,y) = y = F1Q3, see testCase.py
#define variables (a,b,N) and initial conditions ic=y0
a = 0
b = 2
ic = 1
# Question 1 - Exemple 1
def example1_Q3():
    for N in [10, 100, 1000]: 
        plt.figure(N+1)
        ###You can also use T,Y = ode_EulerExp(f1, a, b, ic, N)
        X,Y = ode_EulerExp(f1Q3, a, b, ic, N)
        plt.plot(X,Y,label = 'Explicit Euler with N='+ str(N))
        if exac1Q3:
            Y  = [exac1Q3(x) for x in X]
            plt.plot(X,Y, label = 'Theoretical solution')
        plt.xlabel('x')
        plt.ylabel('y and dy/dx')
        plt.title('Exact & numerical solution, ODE: y’= y on [0; 2]')
        plt.legend()
        plt.grid()
        plt.show()
example1_Q3()  

#Section 2 - Question 2
#Data for EulerSystem method, ODE: y"+y=0; y(0) = 0; y'(0)=1; [a;b]=[0;5]
##f is given by f(x,y,z) = F1Q2, see testCase.py
#define variables (a,b,N) and initial conditions (y(0),y'(0))
a = 0
b = 5
y0 = 0
z0 = 1
def EulerSystem_Q2():
    for N in [10,100,1000]:
        plt.figure(N+2)
        X,Y,Z = EulerSystem(F1Q2, a, b, y0, z0, N)
        plt.plot(X,Y,label='Numerical solution '+str(N))
        if exac1Q2:
            Y = [exac1Q2(x) for x in X]
            plt.plot(X,Y, label = 'Theoretical solution')
        plt.xlabel('x')
        plt.ylabel('y and dy/dx')
        plt.title('Exact & numerical solution, ODE: y"+y=0 on [0; 5]')    
        plt.legend()
        plt.grid()
        plt.show()
EulerSystem_Q2()

#Data for ode_vectEulerExp method, ODE: y"+y=0; y(0) = 0; y'(0)=1; [a;b]=[0;5]
#Hf is given by F(x, (y1,y2)) = F1Q2vect, see testCase.py
#define variables (a,b,N) and initial conditions ic=(y(0),y'(0))
a = 0
b = 5
ic = np.array([0,1])
def example2_Q2():
    for N in [10, 100, 1000]:
        plt.figure(N+3)
        ###Explicit Euler
        X,Y = ode_VectEulerExp(F1Q2vect, a, b, ic, N)
        y, dy = Y[:,0], Y[:,1]
        plt.plot(X, y,label = 'Explicit Euler: solution y(x) with N='+ str(N))
        if exac1Q2:
            Y = [exac1Q2(x) for x in X]
            plt.plot(X,Y, label = 'Theoretical solution')
        plt.xlabel('x')
        plt.ylabel('y and dy/dx')
        plt.title('Exact & numerical solution, ODE: y"+y=0 on [0; 5]')
        plt.legend()
        plt.grid()
        plt.show()
example2_Q2()

