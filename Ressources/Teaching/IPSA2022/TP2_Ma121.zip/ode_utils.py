#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 9 10:43:39 2022
@author: H. El-Otmany
@ This file contain all numerical method  for ODE
@ Input data : 
    - dydx = f(x,y),
    - start value x_0 = a,
    - end value x_f = b, 
    - number of subdivison n
    - Initial condition y0
@ Output : numerical solution y
@Algorithme d Euler (Runge Kutta d'ordre un)
Euler(f , y0, x_0, x_f , N):
    h <--- (x_f - x_0)/N
    Ly <--- y_0, Lx <---- x_0
Pour k de 1 a N faire
    y0 <---y0 + h.f(t0, y0)
    t0 <---t0 + h
    Ly <---Ly, y0; # stocker les solutions
    Lx <---Lx, t0 # stocker les abscisses
retourner Ly; liste des ordonnees y_k, k = 0; 1;... ; N
         Lx; liste des ordonnees x_k, k = 0; 1;... ; N
"""

import numpy as np
import matplotlib.pyplot as plt


#Euler method for iniline function 
def ode_EulerExp(f, a, b, y0, N):
    h = (b-a) / N #step size if h is constant
    Lx = [a]  #Time list
    Ly = [y0] #Initial condition of velocity dy/dx
    x = a
    y = y0
    for i in range(1,N+1):
        #if h isn't constant, we use h=x[i+1]-x[i]
        y += h*f(x, y)
        x += h
        Lx.append(x)
        Ly.append(y)
    return (Lx, Ly)

#Euler method for ODE second order
def EulerSystem(f, a, b, y0, z0, N):
    h = (b-a)/N    #step size if h is constant
    x = a
    y = y0
    z = z0
    Lx = [x]
    Ly = [y]
    Lz = [z]
    for i in range(N):
        #if h isn't constant, we use h=x[i+1]-x[i]
        vf = f(x,y,z)
        y = y+h*z
        z = z+h*vf
        x = x+h
        Lx.append(x)
        Ly.append(y)
        Lz.append(z)
    return (Lx,Ly,Lz)

#Euler method for vector functions F(x,Y) with Y= (y1,y2,....,yn)
#Ok for inline function F(x,y) = a g(y) + b k(x) for example.
def ode_VectEulerExp(f, a, b, ic, N):
      h = (b - a) / N #step size if h is constant
      Lx = np.linspace(a, b, N) 
      Ly = np.empty((N, np.size(ic)), dtype = float) 
      Ly[0,:] = ic
      for i in range(N-1):
          #if h isn't constant, we use h=x[i+1]-x[i]
          Ly[i+1,:] = Ly[i,:] + h*f(Lx[i],Ly[i,:])
      return (Lx, Ly)