#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  8 21:15:05 2022
@ This file contain all test cases
@author: H. El-Otmany
@ This file contain all functions used in TP2
"""
import numpy as np
from math import exp,sin,pi


"""Section 1 - Question 3"""
#Example 1: definition of function for ODE: y'=y; y(0) =1; [a;b]=[0;1]
def f1Q3(x,y):
    return y
def exac1Q3(x):
    return exp(x)
#Example 2: definition of function for ODE: y' + y=x^2 +1; y(0) = 0; [a;b]=[0;5]
def f2Q3(x,y):
    return x*x+1-y
def exac2Q3(x):
    return x*x-2*x+3-3*exp(-x)
#Example 3: definition of function for ODE: (x+1)y'-xy+1=0; y(0) = 2; [a;b]=[0;5]
def f3Q3(x,y):
    return (x*y-1)/(x+1)
def exac3Q3(x):
    return (exp(x)+1)/(x+1)

"""Section 1 - Question 4"""
#Example 1: definition of function for ODE: y'=-xy+1; y(0) =0; [a;b]=[0;5]
def f1Q4(x,y):
    return -x*y + 1

#Example 2: definition of function for ODE: y' = x^2 + y^2; y(0) = 0; [a;b]=[0;1]
def f2Q4(x,y):
    return x*x + y*y

#Example 3: definition of function for ODE: y'=sin(x)sin(y); y(0) = pi/2; [a;b]=[0;10]
def f3Q4(x,y):
    return sin(x)*sin(y)

#Example 4: definition of function for ODE: (x+y)y'=1; y(0) = 5; [a;b]=[0;10]
def f4Q4(x,y):
    return 1/(x+y)


"""Section 2 - Question 2"""
#Example 1: definition of function for y"+y=0; y(0) = 0; y'(0)=1; [a;b]=[0;5]
def F1Q2(x,y,z):
    return -y
#Example 1: definition of function for ODE: y"+y=0; y(0) = 0; y'(0)=1; [a;b]=[0;5]
#Y =(y,y'), compute Y' =(y',y") = (y', -y)
# This function is used for ode_VectEulerExp method 
def F1Q2vect(x,y):
    [z, dz] = y
    return np.array([dz, -z])

def exac1Q2(x):
    return sin(x)

#Example 2: definition of function for ODE: y"-3y'+2y=x^2; y(0) = 0;y'(0)=0 [a;b]=[0;2]
def F2Q2(x,y,z):
    return x*x+3*z-2*y

def exac2Q2(x):
    return x*x/2+3*x/2+7/4-2*exp(x)+1/4*exp(2*x)

"""Section 2 - Question 3"""
#Example 1: definition of function for ODE: y"+sin(y)=0; y(0) = 3;y'(0)=0 [a;b]=[0;20]
def F1Q3(x,y,z):
    return -sin(y)
#Example 2: definition of function for ODE: y"+xy=0; y(0) = 1;y'(0)=0 [a;b]=[0;5]
def F2Q3(x,y,z):
    return -sin(y)
