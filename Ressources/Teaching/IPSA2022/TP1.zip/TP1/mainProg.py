#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:43:39 2022
@author: Hammou El-Otmany
@ this file used for testing
"""
import sys
import math
import numpy as np
from numpy import inf
import matplotlib.pyplot as plt
from scipy.integrate import quad, simps
from prettytable import PrettyTable
#importing all the functions 
from utils import *
from testCase import *
#define variables a, b, n
a = 0
b = 2
n = 100
#Exact value
Iexact= np.arctan(2)
"""
@ Call different method
@ we can use lambda x:1/(1+x**2) 
#instead of trial_f1
 """
Irg = method_RG(trial_f1, a, b, n)
Ird = method_RD(trial_f1, a, b, n)
Imp = method_MP(trial_f1, a, b, n)
It = method_T(trial_f1, a, b, n)
Is = method_S(trial_f1, a, b, n)
Ig2 = method_LG2(trial_f1, a, b, n)
Ig3 = method_LG2(trial_f1, a, b, n)
"""
@ Print method value
 """
print("LG3 method:  Ig3 = ", Ig3)
print("RG method:  Irg = ", Irg,'\n',
      "RD method:  Ird = ", Ird,'\n',
      "MP method:  Imp = ", Imp,'\n', 
      "Trap. method:  It = ", It,'\n', 
      "Simp. method:  Is = ", Is,'\n', 
      "LG2 method:  Ig2 = ", Ig2,'\n', 
      "LG3 method:  Ig3 = ", Ig3,'\n')
"""
@ Print in table
 """
MTables = PrettyTable()  
MTables.field_names = ['Methods', 'Value of I']
MTables.add_row(['RG method', Irg])
MTables.add_row(['RD method', Ird])
MTables.add_row(['MP method', Imp])
MTables.add_row(['Simpson method', Is])
MTables.add_row(['Trapeze method', It])
MTables.add_row(['LG2 method', Ig2])
MTables.add_row(['LG3 method', Ig3])
print(MTables)
"""
@ Compute the integral by using scipy.integrate
 """
h = (b - a)/n
x = np.linspace(a, b, n)
y = trial_f1(x)
It = np.trapz(y,x,h)
print("Trapeze with scipy: It =", It)
"""
@ plotting relative errors
 """
def errors_method(method, f, a, b, Iexact, n_liste):
    number = len(n_liste)
    err_liste = np.empty(number)
    for i in range(len(n_liste)):
        I = method(f, a, b, n_liste[i])
        err_liste[i]=abs((I-Iexact)/Iexact)
    return err_liste
methods={'Rectangles à gauche': method_RG, 
          'Rectangles à droite':method_RD, 
          'Point milieu':method_MP,
          'Trapèzes':method_T, 
          'Simpson':method_S,
          'Gauss Legendre 2':method_LG2,
          'Gauss Legendre 3':method_LG3}

n_liste=list(range(1,50))+list(range(50,200,5))+\
    list(range(200,1000,20))
plt.figure()
for m in methods :
    method = methods[m]
    le = errors_method(method, trial_f1, a, b, Iexact, n_liste)
    plt.loglog(n_liste,le,label=m)
plt.legend()
plt.title('Évolution des erreurs relatives en fonction de n')
plt.show()
