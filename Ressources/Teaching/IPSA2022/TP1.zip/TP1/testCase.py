#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  8 21:15:05 2022
@ This file contain all test cases
@author: H. El-Otmany
"""
import numpy as np
def trial_f1(x):
    return 1/(1+x**2)
def trial_f2(x):
    return np.exp(x)/x