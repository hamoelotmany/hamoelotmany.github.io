#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:43:39 2022
@author: H. El-Otmany
@ This file contain all method (RG,RD,MP,S,
@ T,LG2,LG3)
@ Input data : 
    - function to integrate f,
    - start value a,
    - end value b, 
    - number of subdivison n
@ Output : computed value of integral
"""
import numpy as np
import matplotlib.pyplot as plt
#Formule du retcangle à gauche
def method_RG(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a, b-h, n)
    S = sum(f(x))
    return h*S
#Formule du rectangle à droite
def method_RD(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h,b,n)
    S = sum(f(x))
    return h*S
#Formule du point milieu
def method_MP(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h/2, b-h/2, n)
    S = sum(f(x))
    return h*S
#Formule des trapèzes
def method_T(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h, b-h, n-1)
    S = sum(f(x)) + (f(a) + f(b))/2
    return h*S
#Formule de Simpson
def method_S(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a, b-h, n)
    Sx = sum(f(x[1:]))
    Sm = sum(f(x+h/2))
    A = f(a) + f(b) + 2*Sx + 4*Sm
    return h*A/6

#Formule de Gauss à 2 points
def method_LG2(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h/2, b-h/2, n)
    r = h*np.sqrt(3)/6
    coef1 = x-r
    coef2 = x+r
    Sm = sum(f(coef1))
    Sp = sum(f(coef2))
    A = Sm + Sp
    return A*h/2
#Formule de Gauss à 3 points
def method_LG3(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h/2, b-h/2, n)
    r = h*np.sqrt(0.15)
    coef1 = x - r
    coef2 = x - r
    Sm = sum(f(coef1))
    Sx = sum(f(x))
    Sp = sum(f(coef2))
    A = (Sm + Sp)*5 + 8*Sx
    return A*h/18
