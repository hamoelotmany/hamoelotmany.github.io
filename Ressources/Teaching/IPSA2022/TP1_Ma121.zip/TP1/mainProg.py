#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File: mainProg.py
Created on Wed Feb 16 11:47:43 2022
@author: Hammou El-Otmany
@ this file used for testing
"""
import sys
import math
import numpy as np
from numpy import inf
from math import log, exp, sin,pi, cos
import matplotlib.pyplot as plt
#print method, value, error
#from prettytable import PrettyTable
#call method defined in scipy.integrate
from scipy.integrate import quad, simps
#importing all the functions 
from utils import *
from testCase import *
#define variables a, b, n
a = 1
b = 3
#Exact value of Integral
I_ex= log(3)
"""
@ Call different method
@ we can use lambda x:1/(1+x**2) 
#instead of trial_f1
 """
I_RG = method_RG(trial_f1, a, b, 50)
I_RD = method_RD(trial_f1, a, b, 50)
I_MP = method_MP(trial_f1, a, b, 50)
I_T = method_T(trial_f1, a, b, 50)
"""
@ Print method value
"""
print("RG method: ", I_RG,'\n',
      "RD method: ", I_RD,'\n',
      "MP method: ", I_MP,'\n', 
      "Trap. method: ", I_T,'\n')
"""
@ Print method value for each N subdivisions
"""
for n in [10,50,1000]:
    I_RG = method_RG(trial_f1, a, b, n)
    I_RD = method_RD(trial_f1, a, b, n)
    I_MP = method_MP(trial_f1, a, b, n)
    I_T = method_T(trial_f1, a, b, n)
    print(" n value:",n,"RG method: ", I_RG,'\n',
      "n value:",n,"RD method: ", I_RD,'\n',
      "n value:",n,"MP method: ", I_MP,'\n', 
      "n value:",n,"Trap. method: ", I_T,'\n')
"""
@ Print method value with prettytable
#  """
# MTables = PrettyTable()  
# MTables.field_names = ['Methods','Value of I', 'Error']
# MTables.add_row(['RG method', I_RG,abs((I_ex-I_RG)/I_ex)])
# MTables.add_row(['RD method', I_RD,abs((I_ex-I_RD)/I_exx)])
# MTables.add_row(['MP method', I_MP,abs((I_ex-I_MP)/I_ex)])
# MTables.add_row(['Trapeze method',I_T,abs((I_ex-I_T)/I_ex)])
# print(MTables)
"""
@ Compute the integral by using scipy.integrate
 """
h = (b - a)/n
x = np.linspace(a, b, n)
y = trial_f1(x)
I_Tscipy = np.trapz(y,x,h)
print("Trapeze with scipy: ", I_Tscipy)
"""
@ plotting relative errors
"""
n_liste=list(range(10,1000,10)) 
#+ list(range(10,50))+list(range(50,200,5))+list(range(200,1000,20))
plt.figure()
for m in methods :
    method = methods[m]
    error = errors_method(method, trial_f1, a, b, I_ex, n_liste)
    plt.loglog(n_liste,error,label=m)
plt.legend()
plt.title('Évolution des erreurs relatives en fonction de n')
plt.show()

"""
@ Plotting errors with erors_method2
"""
plt.figure()
n_liste = list(range(10,1000,10))
error_title = 'Évolution des erreurs relatives en fonction de n'
errors_method2(trial_f1, 1, 3, n_liste, I_ex, error_title)
plt.show()
"""
@ Plotting g by using Trapeze's method
"""
plt.figure()
X = []
x = 0.
g = []
pas = 0.01
while x <= 3:
    X.append(x)
    g.append(trial_g11(x))
    x = x + pas
plt.plot(X, g,label='with n = 100')
plt.legend()
plt.title('Plotting g by using Trapeze')
plt.show()


plt.figure()
XX = []
xx = 0.
g1 = []
pas = 0.01
while xx <= pi/2:
    XX.append(xx)
    g1.append(trial_g12(x))
    xx = xx + pas
plt.plot(XX, g1,label='with n = 10000')
plt.legend()
plt.title('Plotting g1 by using Trapeze')
plt.show()



"""
@ Approximated value of I
"""
I_value = method_T(trial_square,1,2,n)
print("value of I:", I_value)
for n in [10,50,100, 150, 250, 500, 800, 1000]:
    I_value = method_T(trial_square,1,2,n)
    print("calcul with n= ",n,"\nvalue of I :", I_value)

