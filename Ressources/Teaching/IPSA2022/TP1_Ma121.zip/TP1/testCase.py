#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File: testCase.py
Created on Wed Feb 16 11:47:43 2022
@ This file contain all test cases
@author: H. El-Otmany
"""
from cmath import sqrt
from math import log, exp, sin,pi, cos
from utils import *
def trial_f1(x):
    return 1/x
def trial_f2(x):
    return log(x+1)/x
def trial_f3(x):
    return exp(sin(x))
def trial_f4(x):
    return cos(x*x)
def trial_g11(x):
    def f(r):
        return exp(-r*r)
    f1 = np.vectorize(f)
    return method_MP(f1,x,2*x,100)
def trial_square(x):
    square = trial_g11(x) **2
    return square



def trial_g12(x):
    def f(r):
        A = 4*sqrt(0.3192754284)
        L = sqrt(1-(sin(0.5*x)**2)*sin(r)**2)
        return A/L
    f2 = np.vectorize(f)
    return method_MP(f2,0,pi/2,10000)
