#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File: utils.py
Created on Wed Feb 16 11:47:43 2022
@author: H. El-Otmany
@ This file contain all method (RG,RD,MP,T)
@ Input data : 
    - function to integrate f,
    - start value a,
    - end value b, 
    - number of subdivison n
@ Output : computed value of integral
"""
import numpy as np
import matplotlib.pyplot as plt
#Formule du retcangle à gauche
def method_RG(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a, b-h, n)
    S = sum(f(x))
    return h*S
#Formule du rectangle à droite
def method_RD(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h,b,n)
    S = sum(f(x))
    return h*S
#Formule du point milieu
def method_MP(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h/2, b-h/2, n)
    S = sum(f(x))
    return h*S
#Formule des trapèzes
def method_T(f, a, b, n):
    h = (b-a)/n
    x = np.linspace(a+h, b-h, n-1)
    S = sum(f(x)) + (f(a) + f(b))/2
    return h*S
"""
@ plotting relative errors
"""
def errors_method(method, f, a, b, I_exact, n_liste):
    number = len(n_liste)
    err_liste = np.empty(number)
    for i in range(len(n_liste)):
        I_app = method(f, a, b, n_liste[i])
        err_liste[i]=abs((I_app-I_exact)/I_exact)
    return err_liste
methods={'Rectangles à gauche': method_RG, 
          'Rectangles à droite':method_RD, 
          'Point milieu':method_MP,
          'Trapèzes':method_T}
"""
@ You can also use this method for plotting errors
"""
def errors_method2(f, a, b, n_liste, I_ex, err_title):
    error_RG = []
    error_RD = []
    error_PM = []
    error_T = []
    I = abs(I_ex)
    for n in n_liste:
        error_RG.append(abs(I_ex - method_RG(f, a, b, n))/I)
        error_RD.append(abs(I_ex - method_RD(f, a, b, n))/I)
        error_PM.append(abs(I_ex - method_MP(f, a, b, n))/I)
        error_T.append(abs(I_ex - method_T(f, a, b, n))/I)
    plt.loglog(n_liste, error_RG,'o', label = 'Rect. gauche')
    plt.loglog(n_liste, error_RD,'+', label = 'Rect.droite')
    plt.loglog(n_liste, error_PM,'*', label = 'Point milieu')
    plt.loglog(n_liste, error_T,'x', label = 'Trapezes')
    plt.legend()
    plt.title(err_title)
    plt.show()
    return error_RG, error_RD, error_PM, error_T