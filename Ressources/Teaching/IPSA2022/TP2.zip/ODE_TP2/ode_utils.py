#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 9 10:43:39 2022
@author: H. El-Otmany
@ This file contain all numerical method  for ODE
@ Input data : 
    - dydt = f(t,y),
    - start value t=a,
    - end value t=b, 
    - number of subdivison n
    - Initial condition y0
@ Output : numerical solution y
@Algorithme d Euler (Runge Kutta d ordre un)
Euler(f , y0, t_0, t_f , N)
Input: f fonction donnees
(t0; y0) point initial
t f abscisse final
N nombre de points de [t_0; t_f ]
    h <--- (t_f -t_0)/N
    Ly <--- y0, Lt ← t0
Pour k de 1 a N faire
    y0 <---y0 + h.f(t0, y0)
    t0 <---t0 + h
    Ly <---Ly, y0; # stocker les solutions
    Lt <---Lt, t0 # stocker les abscisses
Ouptut : Ly liste des ordonnees yk, k = 0; 1;... ; N
         Lt liste des ordonnees tk, k = 0; 1;... ; N
"""

import numpy as np
import matplotlib.pyplot as plt

from scipy.optimize import newton
from scipy.integrate import odeint
from scipy.integrate import solve_ivp
#Euler method for iniline function 
def ode_EulerExp(f, a, b, y0, N):
    h = (b-a) / N #step size if h is constant
    Lt = [a]  #Time list
    Ly = [y0] #Initial condition of velocity dy/dt
    t = a
    y = y0
    for i in range(1,N+1):
        #if h isn't constant, we use h=t[i+1]-t[i]
        y = y + h*f(t, y)
        t = t+ h
        Lt.append(t)
        Ly.append(y)
    return (Lt, Ly)

#Euler method for vector functions F(t,y1,y2,.....)
#Ok for inline function 
def ode_VectEulerExp(f, a, b, ic, N):
      h = (b - a) / N #step size if h is constant
      Lt = np.linspace(a, b, N) 
      Ly = np.empty((N, np.size(ic)), dtype = float) 
      Ly[0,:] = ic
      for i in range(N-1):
          #if h isn't constant, we use h=t[i+1]-t[i]
          Ly[i+1,:] = Ly[i,:] + h*f(Lt[i],Ly[i,:])
      return (Lt, Ly)
  
#Runge-Kutta second order for iniline function & vector function
def ode_RK2(f, a, b, ic, N):
      h = (b - a) / N      #step size if h is constant
      Lt = np.linspace(a, b, N) 
      Ly = np.empty((N, np.size(ic)),dtype = float) 
      Ly[0,:] = ic
      for i in range(N-1):
          #if h isn't constant, we use h = t[i+1]-t[i]
          k1 = h*f(Lt[i], Ly[i,:])
          k2 = h*f(Lt[i] + h/2, Ly[i,:]+k1/2)
          Ly[i+1,:] = Ly[i,:] + k2
      return (Lt, Ly)

#Runge-Kutta fourth order for iniline function & vector function
def ode_RK4(f, a, b,ic, N):
      h = (b - a) / N      #step size if h is constant
      Lt = np.linspace(a, b, N) 
      Ly = np.empty((N, np.size(ic)),dtype = float) 
      Ly[0,:] = ic
      for i in range(N-1):
          #if h isn't constant, we use h=t[i+1]-t[i]
          k1 = h*f(Lt[i], Ly[i,:])
          y1 = Ly[i,:] + 1/2*k1
          k2 = h* f(Lt[i]+h/2, y1)
          y2 = Ly[i,:] + 1/2*k2
          k3 = h* f(Lt[i]+h/2,y2) 
          y3 = Ly[i,:] + k3
          k4 = h* f(Lt[i]+h, y3)
          k = (k1+2*k2+2*k3+k4)/6
          Ly[i+1,:] = Ly[i,:] + k
      return (Lt, Ly)

#Backward Euler or Implicit Euler for iniline function
def ode_ForwardEuler(f, a, b, y0, N):
    h = (b-a) / N #step size if h is constant
    Lt = np.linspace(a,b,N)
    Ly = np.zeros(N)
    Ly[0] = y0
    for i in range(N-1):
        #if h isn't constant, we use h=t[i+1]-t[i]
        s = newton(lambda u: u - Ly[i]- f(Lt[i+1],u) * h, Ly[i+1]) 
        Ly[i+1] = s
    return (Lt, Ly)

#Heun method
def ode_Heun(f, a, b, ic, N): 
    h = (b - a) / N      #step size if h is constant
    Lt = np.linspace(a, b, N) 
    Ly = np.empty((N, np.size(ic)),dtype = float) 
    Ly[0,:] = ic
    for i in range(N-1):
        #if h isn't constant, we use h=t[i+1]-t[i]
        k1 = f(Lt[i], Ly[i,:])
        k2 = f(Lt[i+1], Ly[i,:] + h * k1) 
        Ly[i+1,:] = Ly[i,:] + h * (k1 + k2) / 2
    return (Lt, Ly)
        
#Computing errors 
def error(method, f, a, b, ic, N, sol):
    Lt, Ly = method(f, a, b, ic, N) 
    err = 0
    for i in range(N):
        err = max(err, abs(Ly[i] - sol(Lt[i]))) 
    return err

# Print errors
def error_printing(f, a, b, ic, N, sol):
    print("Errors for N = {} : ".format(N))
    print("Explicit Euler : {}".format(error(ode_EulerExp,f, a, b, ic, N, sol)))
    print("RK2 : {}".format(error(ode_RK2,f, a, b, ic, N, sol)))
    print("RK4 : {}".format(error(ode_RK4,f, a, b, ic, N, sol)))
    print()
    
# Necessary rank N to obtain an uniform apporximation to eps
def necessary_rank(method, f, a, b, ic, N, sol, eps):
    if error(method, f, a, b, ic, N, sol)>eps: #error(methode, n0) > epsilon:
        return None 
    p = 2
    r = N
    while r - p > 1:
        q = (p + r) // 2
        if error(method, f, a, b, ic, q, sol)>eps: #error(methode, c) > epsilon:
            p = q 
        else:
            r = q
    return r

# def order_log2():
#     print('The order of a numerical approximation methods')
#     for method in ['ode_VectEulerExp', 'ode_RK2', 'ode_RK4']:
#         meth = eval(method)
#         order = error(meth,f3,a,b,ic,N,exac3)/error(meth,f3,a, b,ic,N,exac3)
#         print("order "+ method +" : {}".format(log(order,2)))
#     print()