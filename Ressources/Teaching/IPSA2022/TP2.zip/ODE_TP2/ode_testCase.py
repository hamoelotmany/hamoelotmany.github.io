#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  8 21:15:05 2022
@ This file contain all test cases
@author: H. El-Otmany
@ This file contain all functions used in TP2
"""
import numpy as np
from math import exp,sin,pi

#Example 1: definition of function y'=-y + t
def f1(t, y):
    return - y + t
def exac1(t):
    return t - 1 + exp(-t)

#Example 2: definition of function for ODE: y" + y = t
#Y =(y,y'), compute Y' =(y',y") = (y', t-y)
def f2(t,y):
    [z, dz] = y
    return np.array([dz, -z +t])
def exac2(t):
    return t - sin(t)

#Example 3: definition of function y' = y + y**2
def f3(t, y):
    return y + y**2
def exac3(t):
    return exp(t)/(2-exp(t))

#Example 4: exo3-TD3, ODE: y" + ty'+ (1 - t)y = 2
#Y =(y,y'), compute Y' =(y',y") = 
#F(t,Y)= (y', 2-ty'+(1-t)y)
def Fexo3_TD3(t, Y):
    v = Y[0]                   # y
    dv = Y[1]                  # y'
    ddv = 2 -t*dv + (1-t)*v    # y" = 2-ty'+(1-t)y
    return np.array([dv , ddv])

#Example 5: exo4-TD3, ODE: y" + ty'+ (1 - t)y = 2
#Y =(y,y', z), compute Y' =(y',y", z')=F(t,Y)
#F(t,Y)= (y', t+ty'-2z, (4t^2+ 1 − y' − exp(t)y − 2z)/3)
def Fexo4_TD3(t, Y):
    v = Y[0]                 #y
    u = Y[1]                 #y'
    w = Y[2]                 #z
    dy = u                   # y'
    ddy = t + t*v            # y" = t+ty'-2z
    dz = (4*t*t+1-u-exp(t)*v-2*w)/3 #z'=(4t^2+ 1 − y' − exp(t)y − 2z)/3
    return np.array([dy ,ddy , dz])

#Example 6: exo4-TD3, ODE: y' = sin(y(t)) +sin(t) on [0;T]
def Fexo3_TD4(t, y):
    return sin(y) + sin(t)
