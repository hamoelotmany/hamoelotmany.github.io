#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:43:39 2022
@author: Hammou El-Otmany
@ this file used for testing
FYI: corrinfo12
@ solving with solve_ip, we can use :
  *Without tolerence
    - sol = solve_ivp(f2, [a, b], [0, 0], t_eval=t)
    - sol = solve_ivp(f2, [a, b], [0, 0], method= 'RK23', t_eval=t)
    - sol = solve_ivp(f2, [a, b], [0, 0], method= 'RK45', t_eval=t)
    - sol = solve_ivp(f2, [a, b], [0, 0], method= 'LSODA', t_eval=t)
  *with relative and obsolute tolerences
     - sol = solve_ivp(f2, [a, b], [0, 0], method= 'LSODA', t_eval=t,rtol = 1e-8, atol = 1e-8))
@ solving with odeint, we can use :
    - sol = odeint(f2, y0, t, p, tfirst=True)
@Computing errors and orders by using : order_log2()
@Computing necassary rank N to obtain an uniform apporximation to eps by using
    - necessary_rank(method, f, a, b, ic, N,sol, eps)))
"""
import sys
from math import *
import numpy as np
from numpy import inf
import matplotlib.pyplot as plt
from matplotlib.pylab import *
from scipy.integrate import odeint
from scipy.integrate import solve_ivp

# Call all functions defined on utils and testCase
from ode_utils import *
from ode_testCase import *

#define variables (a,b,N) and initial conditions ic=y0
a = 0
b = 2
ic = 0
# Question 1 - Exemple 1
def example1_Q1():
    """To Compute for different value of N, change the line 
    'for N in [100]' to  'for N in [10, 100,1000]' """
    for N in [10, 100, 1000]: 
        plt.figure(N+1)
        ###You can also use T,Y = ode_EulerExp(f1, a, b, ic, N)
        T,Y= ode_VectEulerExp(f1, a, b, ic, N)
        #T,Y = ode_VectEulerExp(f1, a, b, ic, N)
        plt.plot(T,Y,label = 'Explicit Euler with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y= ode_RK2(f1, a, b, ic, N)
        plt.plot(T,Y,label = 'RK2 with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y = ode_RK4(f1, a, b, ic, N)
        plt.plot(T,Y,label = 'RK4 with N='+ str(N))
        if exac1:
            Y  = [exac1(x) for x in T]
            plt.plot(T,Y, label = 'Theoretical solution')
            plt.xlabel('t')
            plt.ylabel('y and dy/dt')
        plt.title('Comparison methods-solving ODE: y’=-y +t on [0; 2]')
        plt.legend()
        plt.grid()
        ###Saving figure for reporting
        #plt.savefig("/Users/mac/Desktop/IPSA2022/Module_Ma322_2022/TP_Ma322/PythonTex2/ex1Q1.png ")
example1_Q1()  

#Question 1 - Exemple 2
#define variables (a,b,N) and initial conditions (y(0),y'(0))
a = 0
b = 5
ic = np.array([0,0])
def example2_Q1():
    """To Compute for different value of N, change the line 
    'for N in [100]' to  'for N in [10, 100,1000]' """
    for N in [10, 100, 1000]:
        plt.figure(N+2)
        ###Explicit Euler for vector function
        T,Y= ode_VectEulerExp(f2, a, b, ic, N)
        y= Y[:,0]
        dy = Y[:,1]
        ###To plot the phase portrait, plot of (y, dy)
        #plt.plot(y, dy,label = 'Explicit Euler: phase with N='+ str(N))
        ###To plot the solutions y as a function of time
        plt.plot(T, y,label = 'Explicit Euler: solution y(t) with N='+ str(N))
        ###Using solve_ip of scipy.integrate
        t = np.linspace(a,b,N) # you can use direclty t_eval=T
        sol = solve_ivp(f2, [a, b], [0, 0], t_eval=t)
        ###To plot the phase portrait, plot (y,dy)
        #plt.plot(sol.y[0], sol.y[1],label = 'Solve_ip: phase with N='+ str(N))
        ###To plot the solutions y as a function of time
        plt.plot(T, sol.y[0],label = 'Solve_ip: solution y(t) with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y = ode_RK2(f2, a, b, ic, N)
        y, dy = Y[:,0], Y[:,1]
        plt.plot(T,y,label = 'RK2: solution y(t) with N='+ str(N))
        ###Runge-Kutta 4 - vector
        T,Y = ode_RK4(f2, a, b, ic, N)
        y, dy = Y[:,0], Y[:,1]
        plt.plot(T,y,label = 'RK4: solution y(t) with N='+ str(N))
        if exac2:
            Y = [exac2(x) for x in T]
            plt.plot(T,Y, label = 'Theoretical solution')
            plt.xlabel('t')
            plt.ylabel('y and dy/dt')
        plt.title('Comparison methods-solving ODE: y"+y=t on [0; 5]')
        plt.legend()
        plt.grid()
        ###Saving figure for reporting
        #plt.savefig("/Users/mac/Desktop/IPSA2022/Module_Ma322_2022/TP_Ma322/PythonTex2/ex2Q1.png ")
        
example2_Q1()


#Question 1 - Exemple 3
#define variables (a,b,N) and initial conditions (y(0),y'(0))
a = 0
b = 0.5
ic = 1
def example3_Q1():
    """To Compute for different value of N, change the line 
    'for N in [100]' to  'for N in [10, 100,1000]' """
    for N in [100]:
        plt.figure(N+3)
        ###You can also use 
        #X,Y= ode_EulerExp(f3, a, b, ic, N)
        ###Euler explicite-vector
        T,Y = ode_VectEulerExp(f3, a, b, ic, N)
        plt.plot(T,Y,label = 'Explicit Euler with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y = ode_RK2(f3, a, b, ic, N)
        plt.plot(T,Y,label = 'RK2 with N='+ str(N))
        ###Runge-Kutta 4 - vector
        T,Y = ode_RK4(f3, a, b, ic, N)
        plt.plot(T,Y,label = 'RK4 with N='+ str(N))
        if exac3:
            Y  = [exac3(x) for x in T]
            plt.plot(T,Y, label = 'Theoretical solution')
            plt.xlabel('t')
            plt.ylabel('y and dy/dt')
        plt.title('Comparison methods-solving ODE: dy/dt=y+y*y on [0; 1/2]')
        plt.legend()
        plt.grid()
        ###Saving figure for reporting
        #plt.savefig("/Users/mac/Desktop/IPSA2022/Module_Ma322_2022/TP_Ma322/PythonTex2/exo3Q1.png ")
example3_Q1()

#Computing log order in base 2 of of a numerical approximation methods
#define variables (a,b,N) and initial conditions (ic=y(0)) in example 1
a = 0
b = 0.5
N = 10000
ic = 1
# print relative errors
error_printing(f3, a, b, ic, N, exac3)

#Necessary rank N to obtain an uniform apporximation to eps
print('Rank for Euler Expl., 1e-2: {}'.format(necessary_rank(ode_VectEulerExp, f3,a,b,ic,N, exac3, 1e-2)))
print('Rank for RK2, 1e-2: {}'.format(necessary_rank(ode_RK2, f3, a,b,ic,N,exac3, 1e-2)))
print('Rank for RK4, 1e-2: {}'.format(necessary_rank(ode_RK4, f3, a,b,ic,N,exac3, 1e-2)))


"""
@Exo3 - TD3
#define variables (a,b,N) and initial conditions (y(0)=0,y'(0)=0)
#I=[a;b]=[0;1]
"""
a = 0
b = 1
ic = np.array([0,0])
def exo3_TD3():
    """To Compute for different value of N, change the line 
    'for N in [100]' to  'for N in [10, 100,1000]' """
    for N in [100]:
        plt.figure(N+4)
        ###Euler explicite-vector
        T, Y = ode_VectEulerExp(Fexo3_TD3, a, b, ic, N)
        y, dy = Y[:,0], Y[:,1]
        ###To plot the phase portrait, plot of (y, dy)
        #plt.plot(y, dy,label = 'Explicit Euler: phase with N='+ str(N))
        ###To plot the solutions y as a function of time
        plt.plot(T, y,label = 'Explicit Euler: solution y(t) with N='+ str(N))
        ###Using solve_ip of scipy.integrate
        t = np.linspace(a,b,N) # you can use direclty t_eval=T
        sol = solve_ivp(Fexo3_TD3, [a, b], [0, 0], t_eval=t)
        #plt.plot(sol.y[0], sol.y[1],label = 'Solve_ip: phase with N='+ str(N))
        ###To plot the solutions y as a function of time
        plt.plot(T, sol.y[0],label = 'Solve_ip: solution y(t) with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y = ode_RK2(Fexo3_TD3, a, b, ic, N)
        y, dy = Y[:,0], Y[:,1]
        plt.plot(T,y,label = 'RK2: solution y(t) with N='+ str(N))
        ###Runge-Kutta 4 - vector
        T,Y = ode_RK4(Fexo3_TD3, a, b, ic, N)
        y, dy = Y[:,0], Y[:,1]
        plt.plot(T,y,label = 'RK4: solution y(t) with N='+ str(N))
        plt.title('Comparison methods-solving ODE: ddydt + tdydt + (1 - t)y = 2 on [0; 1]')
        plt.legend()
        plt.grid()
        ###Saving figure for reporting
        #plt.savefig("/Users/mac/Desktop/IPSA2022/Module_Ma322_2022/TP_Ma322/PythonTex2/exo3TD3.png ")
exo3_TD3()

"""
@Exo4 - TD3
#define variables (a,b,N) and initial conditions (y(0)=0,y'(0)=0, y"(0)=0) 
#I= [0;T]=[0;1]
#eq1: ddydt - tdydt+2z=t; 
#eq2: dydt + e^ty + 3dzdt2z = 4t^2 + 1 
"""
a = 0
b = 1
ic = np.array([0,0,0])
def exo4_TD3():
    """To Compute for different value of N, change the line 
    'for N in [100]' to  'for N in [10, 100,1000]' """
    for N in [100]:
        plt.figure(N+5)
        ###Euler explicite-vector
        T, Y = ode_VectEulerExp(Fexo4_TD3, a, b, ic, N)
        y, dy, z = Y[:,0], Y[:,1], Y[:,2]
        ###To plot the phase portrait, plot of (y, dy)
        #plt.plot(y, dy,label = 'Explicit Euler: phase with N='+ str(N))
        ###To plot the solutions y as a function of time
        plt.plot(T, y,label = 'Explicit Euler: solution y(t) with N='+ str(N))
        plt.plot(T, z,label = 'Explicit Euler: solution z(t) with N='+ str(N))
        ###Using solve_ip of scipy.integrate
        t = np.linspace(a,b,N) # you can use direclty t_eval=T
        sol = solve_ivp(Fexo4_TD3, [a, b], [0, 0, 0], t_eval=t)
        ###To plot the solutions y as a function of time
        plt.plot(T, sol.y[0],label = 'Solve_ip: solution y(t) with N='+ str(N))
        plt.plot(T, sol.y[2],label = 'Solve_ip: solution z(t) with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y = ode_RK2(Fexo4_TD3, a, b, ic, N)
        y, dy, z = Y[:,0], Y[:,1], Y[:,2]
        plt.plot(T,y,label = 'RK2: solution y(t) with N='+ str(N))
        plt.plot(T,z,label = 'RK2: solution z(t) with N='+ str(N))
        ###Runge-Kutta 4 - vector
        T,Y = ode_RK4(Fexo4_TD3, a, b, ic, N)
        y, dy, z = Y[:,0], Y[:,1], Y[:,2]
        plt.plot(T,y,label = 'RK4: solution y(t) with N='+ str(N))
        plt.plot(T,z,label = 'RK4: solution z(t) with N='+ str(N))
        plt.title('Comparison methods-solving of DS')
        plt.legend()
        plt.grid()
        ###Saving figure for reporting
        #plt.savefig("/Users/mac/Desktop/IPSA2022/Module_Ma322_2022/TP_Ma322/PythonTex2/exo4TD3.png ")
exo4_TD3()

"""
@Exo3 - TD4
#define variables (a,b,N) and initial conditions (y(0)=0,y'(0)=0, y"(0)=0) 
#I= [0;T]=[0;1]
#ODE: y' =sin(y(t))+sin(t)'
"""
a = 0
b = 1
ic = 0
def exo3_TD4():
    """To Compute for different value of N, change the line 
    'for N in [100]' to  'for N in [10, 100,1000]' """
    for N in [100]:
        plt.figure(N+6)
        ###Euler explicite-vector
        T, Y = ode_VectEulerExp(Fexo3_TD4, a, b, ic, N)
        ###To plot the solutions y as a function of time
        plt.plot(T, Y,label = 'Explicit Euler: solution y(t) with N='+ str(N))
        ###Using solve_ip of scipy.integrate
        t = np.linspace(a,b,N) # you can use direclty t_eval=T
        sol = solve_ivp(Fexo3_TD4, [a, b],[0], t_eval=T)
        ###To plot the solutions y as a function of time
        plt.plot(t, sol.y[0],label = 'Solve_ip: solution y(t) with N='+ str(N))
        ###Runge-Kutta 2 - vector
        T,Y = ode_RK2(Fexo3_TD4, a, b, ic, N)
        plt.plot(T,Y,label = 'RK2: solution y(t) with N='+ str(N))
        ###Runge-Kutta 4 - vector
        T,Y = ode_RK4(Fexo3_TD4, a, b, ic, N)
        plt.plot(T,Y,label = 'RK4: solution y(t) with N='+ str(N))
        plt.title('Comparison methods-solving of DS')
        plt.legend()
        plt.grid()
        ###Saving figure for reporting
        #plt.savefig("/Users/mac/Desktop/IPSA2022/Module_Ma322_2022/TP_Ma322/PythonTex2/exo3TD4.png")
exo3_TD4()
