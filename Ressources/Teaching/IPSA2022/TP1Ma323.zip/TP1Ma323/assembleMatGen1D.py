#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 18:43:39 2022
@author: H. El-Otmany
@ This file contain the assemble Matrix M
@Input: 
    - Nx (integer): number of subdivision or grid points
    - a (real): strat value
    - b (real): end value
    - m (real): value to define a matrix associated to numerical scheme
@ Output: M associated to numerical scheme defined by m value
"""
from operator import iadd
import numpy as np
import matplotlib.pyplot as plt


"""Assemble matrix
optional variables : a, b
"""

def assembleMatrixGen1(Nx,a,b,alpha,m):
    M = (1+2*m*alpha)*np.eye(N)
    for i in range(Nx-1):
        M[i,i+1] = -m*alpha
        M[i+1,i] = -m*alpha
    return M

"""Inverse of Assembled matrix"""
def inverse(N, a,b, alpha, m):
    M = (1+2*m*alpha)*np.eye(N)
    for i in range(N-1):
        M[i,i+1] = m*alpha
        M[i+1,i] = m*alpha
    inv = np.linalg.inv(M) 
    return inv
