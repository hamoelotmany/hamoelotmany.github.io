#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 18:43:39 2022
@author: H. El-Otmany
@ This file contain all numerical schemes: EE, IE, CN
@ Input data: 
    - N (integer): number of subdivision or grid points
    - tau (real): time step
@global and physical parameters:
    - a (real): strat value of X
    - b (real): end value of X
    - Tmin (real): strat value of t
    - Tmax (real): end value of t
    - nu(real): thermal diffusivity  or viscosity 
    - h(real): grid spacing
@ Output : 
    - Unum: list of numerical solution
    - Tlist: list of time-value
    - Xlist: list of space-value
"""
import numpy as np
import matplotlib.pyplot as plt
from assembleMatGen1D import *

#Geometrical & Physical parameters
a = 0
b = 1
Tmin = 0
Tmax = 5
nu = 0.1

#initial conditions at t=0
def g(x):
    return np.sin(np.pi*x)

def SolEE(N,tau):
    #physical & geomertical parameters
    global a, b, h, Tmin, Tmax, nu, g
    h = (b-a)/(N+1)
    alpha = nu*tau/(h**2)
    Nt = int((Tmax-Tmin)/tau)
    Xlist = np.linspace(a,b,N+2)
    Tlist = np.arange(Nt+1)*tau
    #testing the CFL condition
    if alpha <= 0.5:
        print('CFL condition is OK: EE scheme is stable')
    else:
        print('CFL condition is not OK: EE scheme is not stable')
    #initial condition
    #g = lambda x: sin(np.pi*x)
    ud = g(Xlist[1:N+1])
    # t = 0
    Unum = np.zeros((Nt+1,N+2))
    Unum[0,1:N+1] = ud
    #boundary conditions"""
    #for n in range(0, Nt):
    #    Unum[n,0] = 0
    #    Unum[n,N] =  0
    #computing the numerical solution for all Nt points and for all points of [a,b]
    #if f(X[j],T[n]) neq 0, you must add + tau*f(X[j],T[n])
    #beta = 1 - 2*alpha 
    #for n in range(Nt):
        #for i in range(1,N):
            #Unum[i, n+1] = alpha*(Unum[i+1,n] + Unum[i-1,n]) + beta*Unum[i,n] #+ tau*f(X[j],T[n])  
    M = assembleMatrixGen1(N,a,b, alpha, -1)
    for n in range(Nt):
        Unew = np.dot(M,ud) #or M@ud 
        Unum[n+1,1:N+1] = Unew
    return Xlist,Tlist, Unum

def SolEI(N,tau):
    #physical & geomertical parameters
    global a, b, h, Tmin, Tmax, nu, g
    h = (b-a)/(N+1)
    alpha = nu*tau/(h**2)
    Nt = int((Tmax-Tmin)/tau)
    Xlist = np.linspace(a,b,N+2)
    Tlist = np.arange(Nt+1)*tau
    Mimp = assembleMatrixGen1(N,a,b, alpha, -0.5)
    A = inverse(N, a, b, alpha, -0.5)
    #initial condition
    #g = lambda x: sin(np.pi*x)
    ud = g(Xlist[1:N+1])
    # t = 0
    Unum = np.zeros((Nt+1,N+2))
    Unum[0,1:N+1] = ud
    for n in range(Nt) :
        Unew = np.linalg.solve(Mimp,ud)
        Unum[n+1,1:N+1] = Unew
        #Unum[n+1,:] = np.dot(A, ud[n:,])
    return Xlist, Tlist, Unum


def SolCN(N,tau):
    #physical & geomertical parameters
    global a, b, h, Tmin, Tmax, nu, g
    h = (b-a)/(N+1)
    alpha = nu*tau/(h**2)
    Nt = int((Tmax-Tmin)/tau)
    Xlist = np.linspace(a,b,N+2)
    Tlist = np.arange(Nt+1)*tau
    #initial condition
    #g = lambda x: sin(np.pi*x)
    ud = g(Xlist[1:N+1])
    # t = 0
    Unum = np.zeros((Nt+1,N+2))
    Unum[0,1:N+1] = ud
    Mexp = assembleMatrixGen1(N,a,b, alpha, 0.5)
    Mimp = assembleMatrixGen1(N,a,b, alpha, -0.5)
    for n in range(Nt):
        Unew = np.linalg.solve(Mimp,Mexp@ud)
        Unum[n+1,1:N+1] = Unew
    return Xlist,Tlist, Unum
