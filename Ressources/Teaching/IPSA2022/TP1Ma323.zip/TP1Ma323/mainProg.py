#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 19 18:43:39 2022
@author: Hammou El-Otmany
@ this file used for testing
"""
import sys
import math
import numpy as np
from numpy import inf
import matplotlib.pyplot as plt
#importing all the functions 
from utils import *


#Geometrical & Physical parameters
a = 0
b = 1
c = 0
Tmin = 0
Tmax = 5
nu = 0.1
lineSingle = '-----------------------------------------------------'
print(lineSingle)
print("Question 1&2: Solving 1D-Diffusion Equation using Explicit Euler scheme for different values of h and tau\n")
print(lineSingle)

#plotting and testing each method
#Change SolCN by the method name: SolEE(N,tau), SolEI(N,tau), SolCN(N,tau):
h = 0.05
tau = 0.1
N = round(1/h)-1
Xlist,Tlist,Unum = SolEE(N,tau)
#Tlist in lab work
Tlist = [0,1,2,3,4,5]
#you can use directly Tlist : output of SolCN method
for t in Tlist:

    n = round(t/tau)
    plt.plot(Xlist,Unum[n,:],label = "t = " + str(t))
    plt.legend()
    plt.show()

#Exact solution
def exacSol(X,T):
    Nt = T.size
    Nx = X.size
    Uexac = np.zeros((Nt,Nx))
    a = nu*np.pi**2
    for n in range(Nt):
        Uexac[n] = np.sin(np.pi*X)*np.exp(-a*T[n])
    return Uexac

#Plotting and Testing all methods : SolEE, SolEI, SolCN
T_list = [0, 1, 2, 3, 4, 5]
methods = [SolEE, SolEI, SolCN]
method_Name = ['EE method', 'IE method', 'CN method']
method_Number = 3

#Questions A, B, C, D
questA = [0.05, 0.1]
questB  = [0.05, 0.01]
questC = [0.02, 0.01]
questD = [0.01, 0.005]
testCase = [questA, questB, questC, questD]
testCase_Number = len(testCase)

#Plotting methods in one window
fig,lax = plt.subplots(testCase_Number,method_Number,figsize=(25,25))
fig.subplots_adjust(top = 0.90, bottom = 0.05, left = 0.04, right = 0.95, hspace = 0.5, wspace = 0.25)
for i in range(testCase_Number) :
    h,tau = testCase[i]
    N = round((b-a)/h-1)
    for m in range(method_Number):
        method = methods[m]
        #Calling method
        Xlist, Tlist, Unum = method(N,tau)
        #Computing exact solution at Xlist and Tlist
        Uexac = exacSol(Xlist,Tlist)
        ax = lax[i][m]
        for t in T_list :
            n = int(t/tau)
            ax.plot(Xlist,Unum[n,:],label='t='+str(n*tau))
        ax.legend()
        ax.set_title(method_Name[m]+' h={:.3f} tau={:.3f}'.format(1/(N+1),tau),fontsize=16)
        #Computing errors
        error = np.max(np.abs(Uexac- Unum))
        print('h=',h,'tau=',tau, method_Name[m],'Error =',error)
plt.show()
