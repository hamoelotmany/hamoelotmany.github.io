#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Hammou El-Otmany
"""
import sys
from math import *
import numpy as np
import random
import matplotlib.pyplot as plt
#from statistics import fmean as mean
#from random import choices
#data = [41, 50, 29, 37, 81, 30, 73, 63, 20, 35, 68, 22, 60, 31, 95]
#means = sorted(mean(choices(data, k=len(data))) for i in range(100))
#print(f'The sample mean of {mean(data):.1f} has a 90% confidence '
# f'interval from {means[5]:.1f} to {means[94]:.1f}')

#Initialisation de l'alea sur l'ordinateur
random.seed()

# Pour simuler 100 lancers d'une pièce, on peut mettre les résultats
# des 100 lancers dans un tableau
from random import *
table = [randint(1,2) for n in range(100)]

#Question 1
# Ecrire une fonction experience() qui simule le tirage au sort de N = 10 pièces et 
# rend en sortie le nombre de faces. 
# On pourra utiliser le module Python random et notamment la fonction random.randrange.
def pile_face(N):
    nb_pile = 0
    nb_face = 0
    for i in range(N):
       piece = randint(1,2)  #retourne un nombre entier entre a=0 et b=1
       if piece == 1:
           nb_pile = nb_pile + 1
       else:
           nb_face = nb_face + 1
    return i + 1, nb_pile, nb_face

pile_face(100)

#On désire réaliser une expérience à l’aide d’une pièce de monnaie. 
# On effectue cent tirages successifs, on compte le nombre de fois où la face pile tombe
def experienceDN(N) : 
    s = 0
    for i in range (0,N): 
         s += randint(1,2)   
    return s


def experience():
    liste = [] # créer une liste vide 
    P = 0
    F = 0
    for i in range(10):
        r = randint(1,2) #lancer une pièce à deux faces 0 et 1
        if r == 1:
            a ="Pile"
            P = P +  1
            #liste = liste +[a]
            liste.append(a) # completer la liste avec les tirages
        if r == 2:
            a ="Face"
            F = F + 1
            #liste = liste +[a]
            liste.append(a) 
    return F, P
    #print(liste)
    #print("Nombre d'apparaîtion de Pile : " + str(P))
    #print("Nombre d'apparaîtion de Face : " + str(F))

#Question 2
#Repéter l'exp rience m = 10^4 fois. Construire et afficher un tableau des effectifs. 
# (On pourra le stocker sous la forme d'une liste de N +1 valeurs, 
# chaque valeur de cette liste correspondant à l’effectif d’une
# valeur possible de la variable al atoire X).
def repetition(m):
    for i in range(m):
        F = experience()
        print(F,';', end=' ')

repetition(10)

#ou encore
table = [experience() for m in range(10)]
print("Value of Table", table)
#ou encore
def tirage_piece(n) :  
    F = 0 # initialiser le compteur
    P = 0
    for i in range(n): 
        de = randint(1, 10) 
        if de% 2 == 0 : 
            P += 1 
        else:
            F += 1
    return P, F

tirage_piece(10)

#Question 3
#A partir ce tableau des effectifs, déterminer les différents éléments statistiques usuels
# Construire valeurs/effectifs à partir des données brutes.
# list(float)->list(float),list(int)
# A partir des données brutes retourne 
# une liste des valeurs distinctes et les effectifs associés
def TableauValeurEffectif(Table): 
    Table.sort()
    n = len(Table)
    Values = []
    Effectifs = []
    i = 0
    while i < n:
        j = 1
        x = Table[i]
        while i+j < n and Table[i+j] == x:
            j = j+1
        Values += [x]
        Effectifs += [j]
        i = i+j
    return Values,Effectifs

#Testing function
#table = [1,1,2,3,3,3,5,6,6,6,6,6,6,7,7,8,8,8,8,9,9,10]
#Les effectifs calculés à la main : E =[2,1,3,1,6,2,4,2,1]
#print("Effectifs", TableauValeurEffectif(table))

# Construire la liste des fréquences à partir de la liste des effectifs
# A partir d’une liste d’effectifs
# retourne la liste des fréquences"""

def EffectifToFrequence(effectifs): 
    n = len(effectifs)
    freq = []          #list(int)->list(float)
    S = sum(effectifs) # On utilise la fonction Python, même si on sait le faire. 
    for k in range(n):
        freq += [effectifs[k]/S] 
    return freq

#table = [1,2,3,4,5,6,7] 
#E = [9,30,50,40,30,20,8]
#print("fréquences sont = ", EffectifToFrequence(E))

def EffectifToEffectifCumule(E): 
    EC = [E[0]] #list(int)->list(int)
    for i in range(1,len(E)):
        EC += [EC[-1]+E[i]] 
    return EC

def FrequenceToFrequenceCumule(F): 
    FC = [F[0]] #list(float)->list(float)
    for i in range(1,len(F)):
         FC += [FC[-1] + F[i]] 
    return FC

# On appelle mode de la série statistique x toute modalité de x 
# dont l’effectif est maximal parmi les effectifs de toutes les modalités.
# Lorsque les modes correspondent à des classes, on appelle alors 
# classe modale la classe dont l’effectif est maximal
#list(float),list(float)->float
#les deux listes X et F sont de même longueur
def moyenne(table,F): 
    n = len(table)
    m = 0
    for i in range(n):
        m += table[i]*F[i]
    return m

#Calcul la médiane à partir des données brutes classées
#list(float)->float
#Les valeurs de X sont classées dans l’ordre croissant
def mediane(table): 
    table.sort()    
    n = len(table)
    if n%2 == 1:
        #med = table[int(n/2)]
        med = table[(n-1)//2]
        return med
    else:
        #med = table[int(n/2-1)] + table[int(n/2)])/2
        med = (table[(n-1)//2] + table[n//2])/2
        return med 
#Calcul de la médiane à partir des données valeurs/fréquences
#list(float),list(float)->float
#les deux listes table et F sont de même longueur
def medianeFreq(table,F): 
    table.sort()
    n = len(table)
    i = 0
    s = 0
    while s < 0.5:
        s += F[i]
        i = i+1
    if s == 0.5:
        return (table[i-1] + table[i])/2 
    else:
       return table[i-1]

#list(float),list(int)->list(float)
#les deux listes Table et E sont de même longueur
# retourne la liste des différents modes
def mode(table,E):  
    n = len(table)
    M = E[0]
    S = [table[0]]
    for i in range(1,n):
        if M < E[i]:
            M = E[i]
            S = [table[i]]
        elif M == E[i]:
            S += [table[i]]
    return S

#calcul de la variance et l'ecart-type de données valeurs/effectifs 
#list(float),list(int)->float
#les deux listes table et E sont de même longueur
#retourne la variance et l'ecart-type de série statistique
def variance_ecarttype(table, E): 
    n = len(table)
    m = moyenne(table,E)
    S = 0
    T = 0
    for i in range(n):
        S += E[i]*(table[i]-m)**2
        T += E[i]
    var = S/T # variance
    sigma = (S/T)**(0.5) #ecart-type
    return var, sigma

# Le troisième quartile Q3 est la plus petite valeur de la série telle 
# qu'au moins 75% des valeurs sont inférieures ou égales à Q3.
#list(float),list(float)->float,float
#les deux listes table et F sont de même longueur
#retourne le premier et le troisième quartiles
def Quartiles(table, F): 
    n = len(table)
    i = 0
    s = 0
    while s < 0.25:
        s += F[i]
        i = i+1
    a = table[i-1]
    while s < 0.75:
        s += F[i]
        i = i+1
    return a, table[i-1]

#Question 4
#Représentation graphique du diagramme en batons de données valeurs/effectifs 
#list(float),list(float)->figure
# les deux listes X et E sont de même longueur
# trace une courbe 
def diagramBatons(table, E): 
    n = len(table)
    for i in range(n): 
        plt.plot([table[i], table[i]], [0,E[i]], color='k', linewidth=5)
        plt.show()

#ou encore
#def diagrammeBatons(table,E): 
#    n = len(table)
#    for i in range(n): 
#        plt.bar(table[i]-0.05, E[i], .1, color='b')
#        plt.show()

#Représentation graphique de la courbe des fréquences cumulées de données valeurs/fréquence
#list(float),list(float)->list(float)
# les deux listes X et E sont de même longueur
# trace une courbe
def CourbesFreqCumul(table, F): 
    n = len(table)
    S = 0
    for i in range(n-1):
        S = S + F[i]
        plt.plot([table[i],table[i+1]], [S,S], color='k') 
    plt.plot([table[n-1],table[n-1]+3], [1,1], color='k')
    plt.show()

#Question 6
#Reprendre ce TP avec d'autres valeurs de N, d'autres valeurs de nombre d'Òexpériences
#  m ou d'autres variables aléatoires ... Commenter
#Bernoulli law with two situations (S, E): 0 & 1
def bernoulli(p):
    x = random()
    if p < 0:
        print("probabilité négative !")
    elif p > 1:
        print("probabilité supérieure à 1 !")
    elif x < p:              
        return(1)
    else:
        return(0)

# Binomiale law 
def binomiale(n,p):
    s = 0
    for k in range(n):
        s = s + bernoulli(p)
    return(s)

N = 50
p = 0.4
table = [k for k in range(N)] 
E = (N+1)*[0]
for k in range(10000):
    x = binomiale(N,p) 
    E[x] += 1
diagramBatons(table,E) 
plt.xlim(0,32) 
plt.ylim(0,2000)
plt.show()


#python3 -m venv .venv
#.venv/bin/activate